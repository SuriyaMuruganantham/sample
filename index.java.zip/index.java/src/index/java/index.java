package index.java;

public class index {
	public static void main()
	{
	System.out.println("Hello, Valaxy!!");
	}

}
